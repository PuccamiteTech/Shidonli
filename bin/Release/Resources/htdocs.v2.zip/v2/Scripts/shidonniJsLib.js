function editProfile() {
        var slo = $('#silverlightObject')[0];
        if (slo != null) {
            try {
                $('#silverlightObject')[0].Content.MainScreenControl2.EditProfile();
            }
            catch (e) {
                try {
                    setTimeout("$('#silverlightObject')[0].Content.MainScreenControl2.EditProfile();", 1500);
                } catch (ex) { }
            }
        }
    }

function openMailForm(to, from, subject, body, userId, username) {
    var link = 'Pages/Mailer.aspx?lang=english&to=' + to + '&from=' + Base64encoder.encode(from) + '&subject=' + Base64encoder.encode(subject) + '&body=' + Base64encoder.encode(body) + '&userId=' + userId + '&username=' + Base64encoder.encode(username);
    showModalPopUp(link, "Contact Us");
 }

 function openParentsPage() {
     var slo = $('#silverlightObject')[0];
     if (slo != null) {
         try {
             $('#silverlightObject')[0].Content.MainScreenControl2.ShowParentsPage();
         }
         catch (e) {
             try {
                 setTimeout("$('#silverlightObject')[0].Content.MainScreenControl2.ShowParentsPage();", 1500);
             } catch (ex) { }
         }
     }
 }


 //----------------------------- Base64 encoder --------------------------------
 var Base64encoder = {

     // private property
     _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

     // public method for encoding
     encode: function (input) {
         var output = "";
         var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
         var i = 0;

         input = Base64encoder._utf8_encode(input);

         while (i < input.length) {

             chr1 = input.charCodeAt(i++);
             chr2 = input.charCodeAt(i++);
             chr3 = input.charCodeAt(i++);

             enc1 = chr1 >> 2;
             enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
             enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
             enc4 = chr3 & 63;

             if (isNaN(chr2)) {
                 enc3 = enc4 = 64;
             } else if (isNaN(chr3)) {
                 enc4 = 64;
             }

             output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

         }

         return output;
     },

     // public method for decoding
     decode: function (input) {
         var output = "";
         var chr1, chr2, chr3;
         var enc1, enc2, enc3, enc4;
         var i = 0;

         input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

         while (i < input.length) {

             enc1 = this._keyStr.indexOf(input.charAt(i++));
             enc2 = this._keyStr.indexOf(input.charAt(i++));
             enc3 = this._keyStr.indexOf(input.charAt(i++));
             enc4 = this._keyStr.indexOf(input.charAt(i++));

             chr1 = (enc1 << 2) | (enc2 >> 4);
             chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
             chr3 = ((enc3 & 3) << 6) | enc4;

             output = output + String.fromCharCode(chr1);

             if (enc3 != 64) {
                 output = output + String.fromCharCode(chr2);
             }
             if (enc4 != 64) {
                 output = output + String.fromCharCode(chr3);
             }

         }

         output = Base64encoder._utf8_decode(output);

         return output;

     },

     // private method for UTF-8 encoding
     _utf8_encode: function (string) {
         string = string.replace(/\r\n/g, "\n");
         var utftext = "";

         for (var n = 0; n < string.length; n++) {

             var c = string.charCodeAt(n);

             if (c < 128) {
                 utftext += String.fromCharCode(c);
             }
             else if ((c > 127) && (c < 2048)) {
                 utftext += String.fromCharCode((c >> 6) | 192);
                 utftext += String.fromCharCode((c & 63) | 128);
             }
             else {
                 utftext += String.fromCharCode((c >> 12) | 224);
                 utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                 utftext += String.fromCharCode((c & 63) | 128);
             }

         }

         return utftext;
     },

     // private method for UTF-8 decoding
     _utf8_decode: function (utftext) {
         var string = "";
         var i = 0;
         var c = c1 = c2 = 0;

         while (i < utftext.length) {

             c = utftext.charCodeAt(i);

             if (c < 128) {
                 string += String.fromCharCode(c);
                 i++;
             }
             else if ((c > 191) && (c < 224)) {
                 c2 = utftext.charCodeAt(i + 1);
                 string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                 i += 2;
             }
             else {
                 c2 = utftext.charCodeAt(i + 1);
                 c3 = utftext.charCodeAt(i + 2);
                 string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                 i += 3;
             }

         }

         return string;
     }

 }
 //----------------------------- Base64 encoder end--------------------------------

function navigateURL(urllink) {
    window.open(urllink, "_blank");
}
function CreateBookmarkLink() {
    title = "Shidonni";
    url = location.href;
    if (window.sidebar) {
        // Mozilla Firefox Bookmark 
        window.sidebar.addPanel(title, url, "");
    } else if (window.external) {
        // IE Favorite 
        window.external.AddFavorite(url, title);
    } else if (window.opera && window.print) {
        // Opera Hotlist 
        return true;
    }
}
function openUrl(urllinkk, urllinkpng, slHeight, gifTop) {
    if ("" == urllinkk)
        return; 
    $('#silverlightControlHost').height(slHeight);
    $('#silverlightControlHost > object').height(slHeight);
    $('#silverlightControlHostFooter').html(
            '<a href="'+urllinkk+'" target="_blank" style="display:inline;" >'+
            '<img src="Images/'+ urllinkpng+
            '" style ="border:none ; vertical-align:top; text-align:center"/></a>'
        );
    $('#silverlightControlHostFooter').css(
                { 'display' : 'inline', 'text-align' : 'center' }
            );

    //$('#silverlightControlHost').css('height', slHeight);
                
}
function userLogin(userName) {
    $('#TopMenuUserNameA').show();
    $('#TopMenuLogOutA').show();
    var text = $('#TopMenuUserName').text();
    $('#TopMenuUserName').text(text + ' ' + userName);  
    $('#LanguageBtn').hide();
}

function urlLinkBtnClicked() {
    $('#silverlightControlHost').css('height', 612);
    $('#silverlightControlHost > object').css('height', 612);
    $('#silverlightControlHostFooter').css('display', 'none');
}

function landingPageLoad() {
    logUserSteps("LogLandingPage");
    logSilverLightInstalltionComplete();
        if (!isSilverLightInstall()) {
            logUserSteps("LogSilverLightNoInstalled", null);
        }       
}

function registerFormComplete() {
    logUserSteps("LogRegistrationCompleted");
    clickWiseOnRegisterFormComplete();
    callGoogle_conversion();
}

function registerFormLoad() {
    logUserSteps("LogRegistrationStart");
    clickWiseOnRegisterFormLoad();    
}

function installSilverLightClick() {
    logUserSteps("LogSilverLightInstallClick");
}

//-----------------**** LoginPageLoad ****-------------------
var isClientLoginPageLoadCallResolve = false;
var isSlLoginPageLoadCallResolve = false;
var loginPageLoadEndOnBothFlag = false;


function loginPageLoadSlCall() {
    isSlLoginPageLoadCallResolve = true;
    if (isClientLoginPageLoadCallResolve) {       
            loginPageLoadEndOnBoth();       
    }
}

function loginPageLoadClientCall() {
    isClientLoginPageLoadCallResolve = true;
    if ((isSlLoginPageLoadCallResolve) || (isSilverLightInstall() == false))
        loginPageLoadEndOnBoth();
}

function loginPageLoadEndOnBoth() {
    logSilverLightInstalltionComplete();
    if (!loginPageLoadEndOnBothFlag) {
        loginPageLoadEndOnBothFlag = true;
        logLoginPage();
        clickWiseOnLoginPageLoad();
    }
}
//----------------**** LoginPageLoad end ****--------------------

//------------------------------------
function setIsoStoregeExistForUser(val) {
    isoStoregeExistForUser = val;
    if (isoStoregeExistForUser == "true") {
       logUserSteps("LogAllReadyAMember", null);            
    }
    else{
        createCookie('LogAllReadyAMember' + CONST_statisticVer, "false", 2000);
    }
}
var isoStoregeExistForUser = null;

function logLoginPage() {
    logUserSteps("LogMainPage", function() {
        if (!isSilverLightInstall()) {
            logUserSteps("LogSilverLightNoInstalled", null);
        }
    })
}

function logSilverLightInstalltionComplete(){
    if (readCookie("LogSilverLightInstalltionComplete" + CONST_statisticVer) == null
        && readCookie("LogSilverLightNoInstalled" + CONST_statisticVer) != null) {
            logUserSteps("LogSilverLightInstalltionComplete", null);
    }
}
//------------------------------------

/*
function tls() {
    logUserSteps("LogAllReadyAMember", null);   
}
function isoStoregeExistForUser() {
    logUserSteps("LogAllReadyAMember", null);     
}
*/

function isSilverLightInstall() {
    if (Silverlight.isInstalled("1.0")) 
            return true;
        return false;        
}

function setToolBarCookie(u, p) {
    var iframe = document.getElementById('ToolBarCookieiframe')
    if (iframe != null)
        iframe.parentNode.removeChild(iframe);
    if (document.createElement && (iframe = document.createElement('iframe'))) {
        iframe.name = 't';
        iframe.id = 'ToolBarCookieiframe';
        iframe.src = 'http://srv1.shidonni.com/conduit/cookieSeter.aspx?u=' + u + '&p=' + p;
        iframe.style.display = 'none';
        document.body.appendChild(iframe);
    }
}

function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    createCookie(name, "", -1);
}

var CONST_statisticVer = 1.4;

function logUserSteps(endPointFunctionName, userOnSuccess) {  
    
    createCookie('IsCookieEnuble' + CONST_statisticVer, 'CookieEnuble', 5);
    if (readCookie('IsCookieEnuble'+ CONST_statisticVer) == null) {
        return;
    }
  
    if(readCookie(endPointFunctionName+""+CONST_statisticVer) == null){
        var statisticID = readCookie("StatisticNewSiteID"+CONST_statisticVer)
        if(statisticID == null)
            statisticID = 0;      

        var timeStamp = new Date().getTime();
        var endPointFunctionNameWithTime;
        if (endPointFunctionName.indexOf('?') != -1) {
            endPointFunctionNameWithTime = endPointFunctionName + '&' + timeStamp;
        } else {
            endPointFunctionNameWithTime = endPointFunctionName + '?' + timeStamp;
        }

        var af = $.Params.get('af');

        jQuery.ajax({
            async: false,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            type: "POST",
            url: "StatisticNewSiteService.asmx/" + endPointFunctionNameWithTime,
            data: "{'statisticID':'" + statisticID + "','af':'" + af + "'}",
            success: function (data) {
                createCookie('StatisticNewSiteID' + CONST_statisticVer, data.d, 2000);
                createCookie(endPointFunctionName + "" + CONST_statisticVer, false, 2000);
                if (userOnSuccess != null)
                    userOnSuccess();
            },
            error: function (data) {

            }

        });
    }
}

//------------------------------------  mail sender ----------------------------------------------------------
var sendMailAttempts = 0;
function sendMail(to, subject, body, from, userId, name) {
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        type: "POST",
        url: "MailService.asmx/SentMailNew",
        data: "{'to':'" + to + "','subject':'" + subject + "','body':'" + body + "','from':'" + from + "','userId':'" + userId + "','name':'" + name + "'}",
        success: function (data) {
            sendMailAttempts = 0;           
        },
        error: function (data) {          
            if(sendMailAttempts < 4)
            {
                sendMailAttempts++;
                setTimeout("sendMail(to, subject, body, from, userId, name);",1000);  
            }   
            else
            {
                sendMailAttempts = 0;
                return;
            }  
        }
    });
}


//------------------------------------  mail sender end ------------------------------------------------------
//------------------------------------  dialogMGR obj definition start ---------------------------------------
var $dialogMGR = new dialogMGR();
// --------------  ctor  ------------------
function dialogMGR() {
    this.dialogStackLevel = -1;
    this.dialogHistory = new Array();
}

//dialogMGR.prototype.getName = function (htmlElement) {
//    htmlElement.find('a').etch(function () {
//        var origHref = this.attr('href');

//    });
//}

dialogMGR.prototype.getName = function () {
    return 'dialog' + this.dialogStackLevel;
}

dialogMGR.prototype.getParentDialogName = function () {
    return 'dialog' + (this.dialogStackLevel-1);
}

dialogMGR.prototype.higherStack = function () {
    this.dialogStackLevel++;
}

dialogMGR.prototype.lowerStack = function () {
    this.dialogStackLevel--;
}

dialogMGR.prototype.dialogRollBackContent = function () {
    var contentDivSelector = '#dialog' + this.dialogStackLevel;
    $(contentDivSelector).empty();
    $(contentDivSelector).append(this.retrieve());
}

dialogMGR.prototype.dialogSwitchContent = function (link) {    
    var contentDivSelector = '#dialog' + this.dialogStackLevel ;
    var $oldContent = $(contentDivSelector);
    this.stor($oldContent.clone());
    $oldContent.empty();
    var timeStamp = new Date().getTime();
    if (link.indexOf('?') != -1) {
        link = link + '&' + timeStamp;
    } else {
        link = link + '?' + timeStamp;
    }

    $oldContent.load(link);
}

dialogMGR.prototype.stor = function ($domElement)    // Define Method stor
{
    var i = this.dialogHistory.length;
    this.dialogHistory[i] = $domElement;
}

dialogMGR.prototype.retrieve = function ()    // Define Method Retrieve
{
    var domElement = this.dialogHistory[this.dialogHistory.length - 1];
    $(domElement).width('100%'); 
    this.dialogHistory = jQuery.grep(this.dialogHistory, function (value) {
        return value != domElement;
    })
    return domElement;
}

//------------------------------------  dialogMGR obj definition end  ---------------------------------------


//------------------------------------  QueryStringParser obj definition start  ---------------------------------------
initQueryStringParser();

function initQueryStringParser() {
    //prevent conflicts by wrapping plugin
    (function ($) {
        //private function (by scope)
        function QueryStringParser() {
            this.Values = new Object();
            this.load();
        }

        //add methods to the QueryStringParser class
        $.extend(QueryStringParser.prototype, {
            load: function () {
                //no query string...no problem
                if (window.location.search.length <= 1) {
                    return;
                }

                //get the raw query string without the ?
                var queryString = window.location.search.substring(1);
                //split into pairs
                var pairs = queryString.split('&');
                //foreach pair
                for (var i = 0; i < pairs.length; i++) {
                    //set the value (decode string just in case)
                    this.Values[pairs[i].split('=')[0].toLowerCase()] = decodeURIComponent(pairs[i].split('=')[1]);
                }
            },
            get: function (key) {
                return (this.Values[key.toLowerCase()]) ? this.Values[key.toLowerCase()] : '';
            },
            set: function (key, value) {
                this.Values[key.toLowerCase()] = value;
                //chain...in true jQuery fashion
                return this;
            }
        });

        //the $.extend method doesn't appear to allow overriding toString on prototypes
        QueryStringParser.prototype.toString = function () {
            var params = [];

            for (var prop in this.Values) {
                //add the encoded value
                params.push(prop + "=" + encodeURIComponent(this.Values[prop]));
            }

            //return a complete query string
            return '?' + params.join('&');
        };

        //set the global property
        $.Params = new QueryStringParser();
    })(jQuery);
}



//------------------------------------  QueryStringParser obj definition start  ---------------------------------------