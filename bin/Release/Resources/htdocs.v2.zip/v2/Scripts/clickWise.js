﻿
function addToTracker(name) {
try{
    pageTracker._trackPageview(name);
    }
    catch(e){}
}

function clickWiseOnRegisterFormComplete() {
    try{addToTracker("/RegisterFormComplete"); }
    catch(e){}
}

function clickWiseOnRegisterFormLoad() {
   // addToTracker("/RegisterFormLoad");
}

function clickWiseOnLoginPageLoad() {
    try{addToTracker("/LoginPageLoad"); }
    catch(e){}
}

function callGoogle_conversion() {
    try{
    var iframe = document.getElementById('callGoogle_conversion')
    if (iframe != null)
        iframe.parentNode.removeChild(iframe);
    if (document.createElement && (iframe = document.createElement('iframe'))) {
        iframe.name = 't';
        iframe.id = 'callGoogle_conversion';
        iframe.src = 'http://www.googleadservices.com/pagead/conversion/1034419137/?label=LhlyCLvazgEQwfef7QM&amp;guid=ON&amp;script=0';
        iframe.style.display = 'none';
        document.body.appendChild(iframe);
    } }
    catch(e){}
}



